from enum import Enum

class SamplingType(Enum):
    RANDOM_SAMPLING = 1
    SEQUENTIAL_SAMPLING = 2
