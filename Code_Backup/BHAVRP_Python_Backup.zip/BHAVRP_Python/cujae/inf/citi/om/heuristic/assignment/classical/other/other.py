from abc import ABC, abstractmethod
from ...assignment import Assignment

class Other(Assignment, ABC):
    pass