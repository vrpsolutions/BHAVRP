from abc import ABC
from ...assignment import Assignment

class Cyclic(Assignment, ABC):
    pass