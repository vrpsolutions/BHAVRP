from enum import Enum

class FarthestFirstCentroidSelection(Enum):
    BIGGEST_VALUE = 1
