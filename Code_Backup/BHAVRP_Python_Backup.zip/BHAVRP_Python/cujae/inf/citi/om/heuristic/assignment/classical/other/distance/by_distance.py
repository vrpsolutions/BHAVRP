from abc import ABC
from ....assignment import Assignment

class ByDistance(Assignment, ABC):
    pass