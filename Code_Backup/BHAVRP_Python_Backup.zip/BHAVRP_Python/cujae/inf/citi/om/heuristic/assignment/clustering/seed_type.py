from enum import Enum

class SeedType(Enum):
    FARTHEST_DEPOT = 1
    NEAREST_DEPOT = 2
    RANDOM_DEPOT = 3