from abc import ABC
from ...assignment import Assignment

class ByCluster(Assignment, ABC):
    pass