package cujae.inf.ic.om.heuristic.assignment.classical.cyclic;

import cujae.inf.ic.om.heuristic.assignment.Assignment;

public abstract class Cyclic extends Assignment {}
