package cujae.inf.ic.om.heuristic.assignment.clustering;

public enum SamplingType {
	Random_Sampling, Sequential_Sampling;
}