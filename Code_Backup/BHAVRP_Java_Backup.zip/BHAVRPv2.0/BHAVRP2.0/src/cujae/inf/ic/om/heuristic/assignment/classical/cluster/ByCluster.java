package cujae.inf.ic.om.heuristic.assignment.classical.cluster;

import cujae.inf.ic.om.heuristic.assignment.Assignment;

public abstract class ByCluster extends Assignment {}
