package cujae.inf.ic.om.heuristic.assignment.clustering.hierarchical;

import cujae.inf.ic.om.problem.output.solution.Solution;

public class CURE extends Hierarchical {

	@Override
	public Solution toClustering() {
		return null;
	}
}
