package cujae.inf.ic.om.heuristic.assignment.classical.other;

import cujae.inf.ic.om.heuristic.assignment.Assignment;

public abstract class Other extends Assignment {}
