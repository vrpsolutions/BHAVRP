package cujae.inf.ic.om.heuristic.assignment.clustering;

public enum SeedType {
	Farthest_Depot, Nearest_Depot, Random_Depot;
}