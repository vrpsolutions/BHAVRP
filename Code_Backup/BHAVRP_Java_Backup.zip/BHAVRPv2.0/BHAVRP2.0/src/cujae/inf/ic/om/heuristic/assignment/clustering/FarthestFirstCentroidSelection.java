package cujae.inf.ic.om.heuristic.assignment.clustering;

public enum FarthestFirstCentroidSelection {
	BiggestValue;
}