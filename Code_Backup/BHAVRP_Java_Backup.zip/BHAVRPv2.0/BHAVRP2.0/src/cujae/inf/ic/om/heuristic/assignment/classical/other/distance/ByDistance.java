package cujae.inf.ic.om.heuristic.assignment.classical.other.distance;

import cujae.inf.ic.om.heuristic.assignment.Assignment;

public abstract class ByDistance extends Assignment {}
