package cujae.inf.ic.om.controller.utils;

public enum OrderType {
	Ascendent, Descendent, Input, None, Random;
}
