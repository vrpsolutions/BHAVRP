package cujae.inf.ic.om.heuristic.assignment.others;

public class BasedSaveParallel {

}
