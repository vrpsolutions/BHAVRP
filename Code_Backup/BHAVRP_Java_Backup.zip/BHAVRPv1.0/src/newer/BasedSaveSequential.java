package newer;

public class BasedSaveSequential {

}
