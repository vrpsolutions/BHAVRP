package newer;

public class SimplifiedPlus {

}
