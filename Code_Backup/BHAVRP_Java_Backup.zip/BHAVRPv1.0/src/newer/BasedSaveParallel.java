package newer;

public class BasedSaveParallel {

}
