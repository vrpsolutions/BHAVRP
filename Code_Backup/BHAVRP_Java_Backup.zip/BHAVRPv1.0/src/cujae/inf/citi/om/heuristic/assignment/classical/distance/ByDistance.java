package cujae.inf.citi.om.heuristic.assignment.classical.distance;

import cujae.inf.citi.om.heuristic.assignment.Assignment;

public abstract class ByDistance extends Assignment{


}
