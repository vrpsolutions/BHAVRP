package cujae.inf.citi.om.heuristic.assignment.clustering.hierarchical;

import cujae.inf.citi.om.heuristic.output.Solution;

public class CURE extends Hierarchical{

	@Override
	public Solution toClustering() {
		// TODO Auto-generated method stub
		return null;
	}

}
