package cujae.inf.citi.om.heuristic.assignment.clustering;

public enum SeedType {

	Farthest_Depot, Nearest_Depot, Random_Depot;
}
