package cujae.inf.citi.om.heuristic.assignment.classical.cluster;

import cujae.inf.citi.om.heuristic.assignment.Assignment;

public abstract class ByCluster extends Assignment{

	
}
