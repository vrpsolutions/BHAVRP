package cujae.inf.citi.om.heuristic.assignment.classical.cyclic;

import cujae.inf.citi.om.heuristic.assignment.Assignment;

public abstract class Cyclic extends Assignment {

}
