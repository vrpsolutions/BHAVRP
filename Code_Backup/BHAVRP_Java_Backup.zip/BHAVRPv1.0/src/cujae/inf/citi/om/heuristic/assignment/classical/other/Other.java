package cujae.inf.citi.om.heuristic.assignment.classical.other;

import cujae.inf.citi.om.heuristic.assignment.Assignment;

public abstract class Other extends Assignment{

	
}
