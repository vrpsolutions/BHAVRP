package cujae.inf.citi.om.heuristic.controller;

public enum OrderType {

	Ascendent, Descendent, Input, None, Random;
}
