package cujae.inf.ic.om.factory;

/* Enumerado que indica los tipos de distancia*/

public enum DistanceType {
	
	Chebyshev, Euclidean, Haversine, Manhattan, Real;
}
